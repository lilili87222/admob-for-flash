
#import "YKNativeBannerViewController.h"
#import <GoogleMobileAds/GoogleMobileAds.h>
@interface YKNativeBannerViewController ()

@end

@implementation YKNativeBannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UIView*) initBannerView:(NSString*) bannerKey withSize:(CGSize)cgsize {
    GADNativeExpressAdView*  adBanner = [[GADNativeExpressAdView alloc]
                                initWithAdSize:GADAdSizeFromCGSize(cgsize)]   ;
    adBanner.delegate = self;
    adBanner.rootViewController=self;
    adBanner.adUnitID=bannerKey;
    return adBanner;
}
-(void) sendRequest:(UIView*) bannerView withParam:(NSString*)param{
    [(GADNativeExpressAdView*)bannerView loadRequest:[YKBannerViewController createRequest:param]];
}
-(NSString*) eventData:(GADNativeExpressAdView*) view withParam:(NSString*) param{
    NSString* bannerName=nil;
    for(id key in self.bannerList) {
        UIView* _view=[self.bannerList objectForKey:key];
        if(_view==view){
            bannerName=key;
            break;
        }
    }
    if(bannerName==nil)
        bannerName=@"nil";
    return [NSString stringWithFormat:@"%@_%@",bannerName,param];
}
/// Tells the delegate that the native express ad view successfully received an ad. The delegate may
/// want to add the native express ad view to the view hierarchy if it hasn't been added yet.
- (void)nativeExpressAdViewDidReceiveAd:(GADNativeExpressAdView *)nativeExpressAdView{
    NSString *event_name = @"onNativeBannerReceive";
    CGSize s=nativeExpressAdView.frame.size;
    NSString *sizestr=[NSString stringWithFormat:@"%f_%f",s.width,s.height];
    [self sendEvent:event_name level:[self eventData:nativeExpressAdView withParam:sizestr]];
}

/// Tells the delegate that an ad request failed. The failure is normally due to network
/// connectivity or ad availablility (i.e., no fill).
- (void)nativeExpressAdView:(GADNativeExpressAdView *)nativeExpressAdView
didFailToReceiveAdWithError:(GADRequestError *)error{
    NSString *event_name = @"onNativeBannerFailed";
    NSString* eventData=[self eventData:nativeExpressAdView withParam:[error localizedDescription]];
    [self sendEvent:event_name level:eventData];
}

#pragma mark Click-Time Lifecycle Notifications

/// Tells the delegate that a full screen view will be presented in response to the user clicking on
/// an ad. The delegate may want to pause animations and time sensitive interactions.
- (void)nativeExpressAdViewWillPresentScreen:(GADNativeExpressAdView *)nativeExpressAdView{
    NSString *event_name = @"onNativeBannerPresent";
    NSString *event_level = @"adViewWillPresentScreen";
    NSString* eventData=[self eventData:nativeExpressAdView withParam:event_level];
    [self sendEvent:event_name level:eventData];
}

/// Tells the delegate that the full screen view will be dismissed.
- (void)nativeExpressAdViewWillDismissScreen:(GADNativeExpressAdView *)nativeExpressAdView{
    NSString *event_name = @"onNativeBannerDismiss";
    NSString *event_level = @"onWillDismissScreen";
     NSString* eventData=[self eventData:nativeExpressAdView withParam:event_level];
    [self sendEvent:event_name level:eventData];
}

/// Tells the delegate that the full screen view has been dismissed. The delegate should restart
/// anything paused while handling adViewWillPresentScreen:.
- (void)nativeExpressAdViewDidDismissScreen:(GADNativeExpressAdView *)nativeExpressAdView{
    NSString *event_name = @"onNativeBannerDismiss";
    NSString *event_level = @"onDidDismissScreen";
     NSString* eventData=[self eventData:nativeExpressAdView withParam:event_level];
    [self sendEvent:event_name level:eventData];
}

/// Tells the delegate that the user click will open another app, backgrounding the current
/// application. The standard UIApplicationDelegate methods, like applicationDidEnterBackground:,
/// are called immediately before this method is called.
- (void)nativeExpressAdViewWillLeaveApplication:(GADNativeExpressAdView *)nativeExpressAdView{
    NSString *event_name = @"onNativeBannerLeaveApplication";
    NSString *event_level = @"adViewWillLeaveApplication";
     NSString* eventData=[self eventData:nativeExpressAdView withParam:event_level];
    [self sendEvent:event_name level:eventData];
}

@end
