#import "ykadmob.h"
#import "FlashRuntimeExtensions.h"
#import "YKAdmobAdsSwap.h"


YKAdmobAdsSwap *ykadmobAdsSwap;

NSString* admobGetString(FREObject obj){
    const uint8_t *value;
    uint32_t length = 0;
    NSString *isTesting =nil;
    if(FREGetObjectAsUTF8( obj, &length, &value)!=FRE_OK ){
        isTesting=nil;
    }else{
        isTesting = [NSString stringWithUTF8String: (char*) value];
    }
    return isTesting;
}


/* admobExtInitializer()
 * The extension initializer is called the first time the ActionScript side of the extension
 * calls ExtensionContext.createExtensionContext() for any context.
 *
 * Please note: this should be same as the <initializer> specified in the extension.xml
 */
void admobExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet)
{
    //NSLog(@"Entering admobExtInitializer()");
    
    *extDataToSet = NULL;
    *ctxInitializerToSet = &admobContextInitializer;
    *ctxFinalizerToSet = &admobContextFinalizer;
    
    //NSLog(@"Exiting admobExtInitializer()");
}

/* admobExtFinalizer()
 * The extension finalvoidizer is called when the runtime unloads the extension. However, it may not always called.
 *
 * Please note: this should be same as the <finalizer> specified in the extension.xml
 */
void admobExtFinalizer(void* extData)
{
    return;
}

/* ContextInitializer()
 * The context initializer is called when the runtime creates the extension context instance.
 */
void admobContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet)
{
    static FRENamedFunction func[] =
    {
        MAP_FUNCTION(admobHideBanner, NULL),
        MAP_FUNCTION(admobShowBannerAbsolute, NULL),
        MAP_FUNCTION(admobShowBanner, NULL),
        MAP_FUNCTION(admobIsInterstitialReady, NULL),
        MAP_FUNCTION(admobShowInterstitial, NULL),
        MAP_FUNCTION(admobCacheInterstitial, NULL),
        MAP_FUNCTION(admobIsVideoReady, NULL),
        MAP_FUNCTION(admobShowVideo, NULL),
        MAP_FUNCTION(admobCacheVideo, NULL),
        MAP_FUNCTION(admobSetAppMuted, NULL),
        MAP_FUNCTION(admobSetAppVolume, NULL),
        MAP_FUNCTION(admobInitAdmobSDK, NULL),
        MAP_FUNCTION(getScreenSize, NULL)
    };
    
    *numFunctionsToTest = sizeof(func) / sizeof(FRENamedFunction);
    *functionsToSet = func;
    ykadmobAdsSwap=[[YKAdmobAdsSwap alloc]init];
    [ykadmobAdsSwap lsetContext:ctx];
}

/* ContextFinalizer()
 * The context finalizer is called when the extension's ActionScript code
 * calls the ExtensionContext instance's dispose() method.
 * If the AIR runtime garbage collector disposes of the ExtensionContext instance, the runtime also calls ContextFinalizer().
 */
void admobContextFinalizer(FREContext ctx)
{
    if(ykadmobAdsSwap!=nil)
        [ykadmobAdsSwap release];
    return;
}

/* This is a TEST function that is being included as part of this template.
 *
 * Users of this template are expected to change this and add similar functions
 * to be able to call the native functions in the ANE from their ActionScript code
 */



ANE_FUNCTION(admobShowBannerAbsolute){
    int32_t x,y,w,h;
    FREGetObjectAsInt32(argv[0], &x);
    FREGetObjectAsInt32(argv[1], &y);
    FREGetObjectAsInt32(argv[2], &w);
    FREGetObjectAsInt32(argv[3], &h);
    NSString *admobID=admobGetString(argv[4]);
    NSString *instanceName=admobGetString(argv[5]);
    NSString *param =admobGetString(argv[6]);
  //  NSString *nativeType=admobGetString(argv[7]);
   instanceName= [ykadmobAdsSwap showBannerAbsolute:CGSizeMake(w, h) atPoint:CGPointMake(x, y) withBannerKey:admobID withBannerName:instanceName withParam:param ];
    FREObject ret;
    if(FRENewObjectFromUTF8((uint32_t)[instanceName length] , (const uint8_t*)[instanceName UTF8String], &ret)==FRE_OK)
    {
        return ret;
    }else{
        return nil;
    }
}
ANE_FUNCTION(admobShowBanner){
    int32_t position,offY,w,h;
    FREGetObjectAsInt32(argv[0], &position);
    FREGetObjectAsInt32(argv[1], &offY);
    FREGetObjectAsInt32(argv[2], &w);
    FREGetObjectAsInt32(argv[3], &h);
    
    NSString *admobID=admobGetString(argv[4]);
    NSString *instanceName=admobGetString(argv[5]);
    NSString *param =admobGetString(argv[6]);
  //  NSString *nativeType=admobGetString(argv[7]);
    instanceName=[ykadmobAdsSwap showBanner:CGSizeMake(w, h) atPoint:CGPointMake(position, offY) withBannerKey:admobID withBannerName:instanceName withParam:param ];
    FREObject ret;
    if(FRENewObjectFromUTF8((uint32_t)[instanceName length] , (const uint8_t*)[instanceName UTF8String], &ret)==FRE_OK)
    {
        return ret;
    }else{
        return nil;
    }
}

ANE_FUNCTION(admobHideBanner){
    NSString* bannerName=admobGetString(argv[0]);;
    [ykadmobAdsSwap hideBanner:bannerName];
    return nil;
}
ANE_FUNCTION(admobSetAppMuted){
    uint32_t x;
    FREGetObjectAsBool(argv[0],&x);
    [GADMobileAds sharedInstance].applicationMuted=x;
   // NSString* bannerName=admobGetString(argv[0]);;
   // [ykadmobAdsSwap hideBanner:bannerName];
    return nil;
}
ANE_FUNCTION(admobSetAppVolume){
    double x;
    FREGetObjectAsDouble(argv[0],&x);
    [GADMobileAds sharedInstance].applicationVolume=(float)x;
    // NSString* bannerName=admobGetString(argv[0]);;
    // [ykadmobAdsSwap hideBanner:bannerName];
    return nil;
}

ANE_FUNCTION(admobIsInterstitialReady){
    BOOL isready= [ykadmobAdsSwap isInterstitialReady];
    FREObject retVal;
    if(FRENewObjectFromBool(isready, &retVal) == FRE_OK){
        return retVal;
    }else{
        return nil;
    }
}
ANE_FUNCTION(admobShowInterstitial){
    [ykadmobAdsSwap showInterstitial];
    return nil;
}

ANE_FUNCTION(admobCacheInterstitial){
    NSString *institialID=admobGetString(argv[0]);
    NSString *param=admobGetString(argv[1]);
    [ykadmobAdsSwap cacheInterstitial:institialID withParam:param];
    return nil;
}

ANE_FUNCTION(admobIsVideoReady){
    BOOL isready= [ykadmobAdsSwap isVideoReady];
    FREObject retVal;
    if(FRENewObjectFromBool(isready, &retVal) == FRE_OK){
        return retVal;
    }else{
        return nil;
    }
}
ANE_FUNCTION(admobShowVideo){
    [ykadmobAdsSwap showVideo];
    return nil;
}

ANE_FUNCTION(admobCacheVideo){
    NSString *institialID=admobGetString(argv[0]);
    NSString *param=admobGetString(argv[1]);
    [ykadmobAdsSwap cacheVideo:institialID withParam:param];
    return nil;
}

ANE_FUNCTION(admobInitAdmobSDK){
    NSString *param=admobGetString(argv[0]);
    [ykadmobAdsSwap initAdmobSDK:param];
    return nil;
}

ANE_FUNCTION(getScreenSize)
{
    CGRect rx = [ UIScreen mainScreen ].bounds;
    CGFloat scale_screen = [UIScreen mainScreen].scale;
    NSString* mac=@"%f_%f_%f";
    mac=[NSString stringWithFormat:mac,rx.size.width,rx.size.height,scale_screen];
    FREObject ret;
    if(FRENewObjectFromUTF8((uint32_t)[mac length] , (const uint8_t*)[mac UTF8String], &ret)==FRE_OK)
    {
        return ret;
    }else{
        return nil;
    }
}

