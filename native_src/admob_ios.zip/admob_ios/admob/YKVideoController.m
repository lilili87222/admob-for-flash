#import "YKVideoController.h"
#import "YKBannerViewController.h"
@interface YKVideoController (){
    GADRewardBasedVideoAd* interstitial;
}

@end

@implementation YKVideoController
@synthesize context;
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


-(BOOL)isVideoReady{
    if(interstitial==nil){
        interstitial=[GADRewardBasedVideoAd sharedInstance];
        interstitial.delegate=self;
    }
    return [interstitial isReady];
}
-(void)showVideo{
    if([self isVideoReady]){
        UIWindow* parentWin=[[UIApplication sharedApplication] keyWindow];
        if(self.view.superview==nil)
        [parentWin addSubview:self.view];
        [interstitial presentFromRootViewController:self];
    }
}
-(void)cacheVideo:(NSString*)interstitialKey withParam:(NSString *)param{
    if(interstitial==nil){
        interstitial=[GADRewardBasedVideoAd sharedInstance];
        interstitial.delegate=self;
    }
    [interstitial loadRequest:[YKBannerViewController createRequest:param] withAdUnitID:interstitialKey];
}


/// Tells the delegate that the reward based video ad has rewarded the user.
- (void)rewardBasedVideoAd:(GADRewardBasedVideoAd *)rewardBasedVideoAd
   didRewardUserWithReward:(GADAdReward *)reward{
    NSString *event_name = @"onVideoRewarded";
    NSString *rewardstr=[NSString stringWithFormat:@"%@",reward.amount ];
    [self sendEvent:event_name level:rewardstr];
}

/// Tells the delegate that the reward based video ad failed to load.
- (void)rewardBasedVideoAd:(GADRewardBasedVideoAd *)rewardBasedVideoAd
    didFailToLoadWithError:(NSError *)error{
    NSString *event_name = @"onVideoLoadFail";
    [self sendEvent:event_name level:[error description]];
}

/// Tells the delegate that a reward based video ad was received.
- (void)rewardBasedVideoAdDidReceiveAd:(GADRewardBasedVideoAd *)rewardBasedVideoAd{
    NSString *event_name = @"onVideoReceive";
    [self sendEvent:event_name level:event_name];
}

/// Tells the delegate that the reward based video ad opened.
- (void)rewardBasedVideoAdDidOpen:(GADRewardBasedVideoAd *)rewardBasedVideoAd{
    NSString *event_name = @"onVideoOpen";
    [self sendEvent:event_name level:event_name];
}

/// Tells the delegate that the reward based video ad started playing.
- (void)rewardBasedVideoAdDidStartPlaying:(GADRewardBasedVideoAd *)rewardBasedVideoAd{
    NSString *event_name = @"onVideoPlaying";
    [self sendEvent:event_name level:event_name];
}

/// Tells the delegate that the reward based video ad closed.
- (void)rewardBasedVideoAdDidClose:(GADRewardBasedVideoAd *)rewardBasedVideoAd{
    if(self.view.superview!=nil){
        [self.view removeFromSuperview];
    }
    NSString *event_name = @"onVideoClosed";
    [self sendEvent:event_name level:event_name];
}

/// Tells the delegate that the reward based video ad will leave the application.
- (void)rewardBasedVideoAdWillLeaveApplication:(GADRewardBasedVideoAd *)rewardBasedVideoAd{
    NSString *event_name = @"onVideoLeaveApplication";
    [self sendEvent:event_name level:event_name];
}
- (void)rewardBasedVideoAdDidCompletePlaying:(GADRewardBasedVideoAd *)rewardBasedVideoAd{
    NSString *event_name = @"onVideoCompleted";
    [self sendEvent:event_name level:event_name];
}
-(void) sendEvent:(NSString *)type
            level:(NSString *)level{
    if(context!=nil){
        FREDispatchStatusEventAsync(self.context, (uint8_t*)[type UTF8String], (uint8_t*)[level UTF8String]);
    }
}
@end
