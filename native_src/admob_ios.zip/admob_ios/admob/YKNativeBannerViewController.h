//
//  NativeBannerViewController.h
//  admob
//
//  Created by zhouyingke on 16/6/2.
//
//

#import <UIKit/UIKit.h>
#import "YKBannerViewController.h"
#import <GoogleMobileAds/GoogleMobileAds.h>
@interface YKNativeBannerViewController :YKBannerViewController <GADNativeExpressAdViewDelegate>

@end
