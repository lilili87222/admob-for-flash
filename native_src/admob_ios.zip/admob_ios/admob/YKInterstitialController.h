#import <UIKit/UIKit.h>
#import "FlashRuntimeExtensions.h"
#import <GoogleMobileAds/GoogleMobileAds.h>
@interface YKInterstitialController : UIViewController <GADInterstitialDelegate>
@property (nonatomic,assign) FREContext context;
-(BOOL)isInterstitialReady;
-(void)showInterstitial;
-(void)cacheInterstitial:(NSString*)interstitialKey withParam:(NSString*) param;
@end
