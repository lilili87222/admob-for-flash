#import "YKInterstitialController.h"
#import "YKBannerViewController.h"
@interface YKInterstitialController (){
    GADInterstitial* interstitial;
}

@end

@implementation YKInterstitialController
@synthesize context;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(BOOL)isInterstitialReady{
    if(interstitial==nil)return NO;
    if([interstitial hasBeenUsed]) return NO;
    return [interstitial isReady];
}
-(void)showInterstitial{
    if([self isInterstitialReady]){
        UIWindow* parentWin=[[UIApplication sharedApplication] keyWindow];
        if(self.view.superview==nil)
        [parentWin addSubview:self.view];
        [interstitial presentFromRootViewController:self];
    }
}
-(void)cacheInterstitial:(NSString*)interstitialKey withParam:(NSString *)param{
    if(interstitial!=nil&&[interstitial hasBeenUsed]){
        interstitial.delegate=nil;
        interstitial=nil;
    }
    if(interstitial==nil){
        interstitial=[[GADInterstitial alloc]initWithAdUnitID:interstitialKey];
        interstitial.delegate=self;
    }
    [interstitial loadRequest:[YKBannerViewController createRequest:param]];
}


// Sent when an interstitial ad request succeeded.  Show it at the next
// transition point in your application such as when transitioning between view
// controllers.
-(void) sendEvent:(NSString *)type
            level:(NSString *)level{
    // NSLog(@"发送事件%@",type);
    if(context!=nil){
        FREDispatchStatusEventAsync(self.context, (uint8_t*)[type UTF8String], (uint8_t*)[level UTF8String]);
    }
    //[type release];
    //[level release];
}
- (void)interstitialDidReceiveAd:(GADInterstitial *)ad{
    NSString *event_name = @"onInterstitialReceive";
    [self sendEvent:event_name level:event_name];
}

// Sent when an interstitial ad request completed without an interstitial to
// show.  This is common since interstitials are shown sparingly to users.
- (void)interstitial:(GADInterstitial *)ad didFailToReceiveAdWithError:(GADRequestError *)error{
    NSString *event_name = @"onInterstitialFailedReceive";
    [self sendEvent:event_name level:[error localizedDescription]];
}

#pragma mark Display-Time Lifecycle Notifications

// Sent just before presenting an interstitial.  After this method finishes the
// interstitial will animate onto the screen.  Use this opportunity to stop
// animations and save the state of your application in case the user leaves
// while the interstitial is on screen (e.g. to visit the App Store from a link
// on the interstitial).
- (void)interstitialWillPresentScreen:(GADInterstitial *)ad{
    NSString *event_name = @"onInterstitialPresent";
    [self sendEvent:event_name level:event_name];
}

// Sent before the interstitial is to be animated off the screen.
-  (void)interstitialWillDismissScreen:(GADInterstitial *)ad{
    NSString *event_name = @"interstitialWillDismissScreen";
    [self sendEvent:event_name level:@"interstitialWillDismissScreen"];
}

// Sent just after dismissing an interstitial and it has animated off the
// screen.
- (void)interstitialDidDismissScreen:(GADInterstitial *)ad{
    if(self.view.superview!=nil){
        [self.view removeFromSuperview];
    }
    interstitial.delegate=nil;
    interstitial=nil;
    NSString *event_name = @"onInterstitialDismiss";
    [self sendEvent:event_name level:@"interstitialDidDismissScreen"];
}

// Sent just before the application will background or terminate because the
// user clicked on an ad that will launch another application (such as the App
// Store).  The normal UIApplicationDelegate methods, like
// applicationDidEnterBackground:, will be called immediately before this.
- (void)interstitialWillLeaveApplication:(GADInterstitial *)ad{
    NSString *event_name = @"onInterstitialLeaveApplication";
    [self sendEvent:event_name level:event_name];
}
@end
