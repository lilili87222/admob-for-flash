#import <UIKit/UIKit.h>
#import "FlashRuntimeExtensions.h"
#import <GoogleMobileAds/GoogleMobileAds.h>
@interface YKVideoController : UIViewController <GADRewardBasedVideoAdDelegate>
@property (nonatomic,assign) FREContext context;
-(BOOL)isVideoReady;
-(void)showVideo;
-(void)cacheVideo:(NSString*)interstitialKey withParam:(NSString*) param;
@end
