#import <Foundation/Foundation.h>
#import "FlashRuntimeExtensions.h"
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "YKNativeBannerViewController.h"
#import "YKClassicBannerViewController.h"
#import "YKInterstitialController.h"
#import "YKVideoController.h"
@interface YKAdmobAdsSwap : NSObject<NSURLSessionDelegate>

@property (nonatomic,assign) FREContext context;
//@property (nonatomic,retain) YKNativeBannerViewController* nativeController;
@property (nonatomic,retain) YKClassicBannerViewController* admobController;
@property (nonatomic,retain) YKInterstitialController* interstitialController;
@property (nonatomic,retain) YKVideoController* videoController;

-(NSString*)showBannerAbsolute:(CGSize)size atPoint:(CGPoint)point withBannerKey:(NSString*)bannerKey withBannerName:(NSString*)name withParam:(NSString*)param ;
-(NSString*)showBanner:(CGSize)size atPoint:(CGPoint)point withBannerKey:(NSString*)bannerKey withBannerName:(NSString*)name withParam:(NSString*)param ;
-(void)hideBanner:(NSString*)name;

-(BOOL)isInterstitialReady;
-(void)showInterstitial;
-(void)cacheInterstitial:(NSString*)interstitialKey withParam:(NSString*) param;

-(BOOL)isVideoReady;
-(void)showVideo;
-(void)cacheVideo:(NSString*)videoKey withParam:(NSString*) param;
-(void)initAdmobSDK:(NSString*)appID;
-(void)lsetContext:(FREContext)ctx;
@end
