#import "YKAdmobAdsSwap.h"



@implementation YKAdmobAdsSwap{
    
}
@synthesize admobController;
@synthesize interstitialController;
@synthesize videoController;
@synthesize context;
- (id)init
{
    self = [super init];
    if (self) {
        admobController=[[YKClassicBannerViewController alloc]init];
        interstitialController=[[YKInterstitialController alloc]init];
        videoController=[[YKVideoController alloc]init];
        
    }
    return self;
}
-(void)lsetContext:(FREContext)ctx{
    self.context=ctx;
    admobController.context=ctx;
    interstitialController.context=ctx;
    videoController.context=ctx;
  
}
-(NSDictionary*) jsonToDic:(NSString*) _adProperties{
    NSDictionary* dic=nil;
    if(_adProperties!=nil){
        NSData* jsonData=[_adProperties dataUsingEncoding:NSUTF8StringEncoding];
        NSError* parseError=nil;
        id jsonObject=[NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&parseError];
        if(jsonObject!=nil&&[jsonObject isKindOfClass:[NSDictionary class]]){
            dic=(NSDictionary*)jsonObject;
        }
    }
    return dic;
}

-(NSString*)showBannerAbsolute:(CGSize)size atPoint:(CGPoint)point withBannerKey:(NSString*)bannerKey withBannerName:(NSString*)instanceName withParam:(NSString*)param {
    instanceName=[admobController createBanner:bannerKey withName:instanceName withSize:size  withParam:param];
    [admobController showBannerABS:instanceName atX:point.x atY:point.y withParam:param];
    return instanceName;
}
-(NSString*)showBanner:(CGSize)size atPoint:(CGPoint)point withBannerKey:(NSString*)bannerKey withBannerName:(NSString*)instanceName withParam:(NSString*)param {
    instanceName=[admobController createBanner:bannerKey withName:instanceName withSize:size  withParam:param];
    [admobController showRelationBanner:instanceName atPosition:point.x withOffY:point.y withParam:param];
    return instanceName;
}
-(void)hideBanner:(NSString*)name{
    [admobController removeBanner:name];
}

-(BOOL)isInterstitialReady{
    return [interstitialController isInterstitialReady];
}
-(void)showInterstitial{
    [interstitialController showInterstitial];
}
-(void)cacheInterstitial:(NSString*)interstitialKey withParam:(NSString*) param{
    [interstitialController cacheInterstitial:interstitialKey withParam:param];
}

-(BOOL)isVideoReady{
    return [videoController isVideoReady];
}
-(void)showVideo{
    [videoController showVideo];
}
-(void)cacheVideo:(NSString*)videoKey withParam:(NSString*) param{
    [videoController cacheVideo:videoKey withParam:param];
}
-(void)initAdmobSDK:(NSString*)param{
    [[GADMobileAds sharedInstance] startWithCompletionHandler:^(GADInitializationStatus *_Nonnull status){
        if(context!=nil&&context!=nil){
            FREDispatchStatusEventAsync(context, (uint8_t*)[@"onInitialized" UTF8String], (uint8_t*)[@"AdmobEvent" UTF8String]);
        }
    }];
    
    NSDictionary *dic=[self jsonToDic:param];
    if(dic==nil)return;
    NSArray* keyList=[dic allKeys];
    GADRequestConfiguration *requestConfiguration=[GADMobileAds.sharedInstance requestConfiguration];
    if([keyList containsObject:@"isChildApp"]){
        BOOL isForChildDirectedTreatment=[[dic objectForKey:@"isChildApp"] boolValue];
        if(isForChildDirectedTreatment){
            [requestConfiguration tagForChildDirectedTreatment:YES];
        }
    }
    if([keyList containsObject:@"isUnderAgeOfConsent"]){
        BOOL isUnderAgeOfConsent=[[dic objectForKey:@"isUnderAgeOfConsent"] boolValue];
        if(isUnderAgeOfConsent){
            [requestConfiguration tagForUnderAgeOfConsent:YES];
        }
    }
    if([keyList containsObject:@"maxAdContentRating"]){
        NSString* maxAdContentRating=[dic objectForKey:@"maxAdContentRating"];
        requestConfiguration.maxAdContentRating=maxAdContentRating;
    }
    
    if([keyList containsObject:@"isAppMuted"]){
        BOOL isAppMuted=[[dic objectForKey:@"isAppMuted"] boolValue];
        [GADMobileAds sharedInstance].applicationMuted=isAppMuted;
    }
    
    if([keyList containsObject:@"volume"]){
        int appVolume=[[dic objectForKey:@"volume"] intValue];
        if(appVolume<0||appVolume>100)appVolume=100;
        [GADMobileAds sharedInstance].applicationVolume=appVolume/100;
    }
}
@end
