

#import <Foundation/Foundation.h>
#import "FlashRuntimeExtensions.h"

#define ANE_FUNCTION(f) FREObject (f)(FREContext ctx, void *data, uint32_t argc, FREObject argv[])
#define MAP_FUNCTION(f, data) { (const uint8_t*)(#f), (data), &(f) }
//#define AB_DEFAULT_BANNER_NAME @"defaultBanner";
/* admobExtInitializer()
 * The extension initializer is called the first time the ActionScript side of the extension
 * calls ExtensionContext.createExtensionContext() for any context.
 *
 * Please note: this should be same as the <initializer> specified in the extension.xml 
*/
void admobExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet);

/* admobExtFinalizer()
 * The extension finalizer is called when the runtime unloads the extension. However, it may not always called.
 *
 * Please note: this should be same as the <finalizer> specified in the extension.xml 
*/
void admobExtFinalizer(void* extData);

/* ContextInitializer()
 * The context initializer is called when the runtime creates the extension context instance.
*/
void admobContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet);

/* ContextFinalizer()
 * The context finalizer is called when the extension's ActionScript code
 * calls the ExtensionContext instance's dispose() method.
 * If the AIR runtime garbage collector disposes of the ExtensionContext instance, the runtime also calls ContextFinalizer().
*/
void admobContextFinalizer(FREContext ctx);

/* This is a sample function that is being included as part of this template. 
 *
 * Users of this template are expected to change this and add similar functions 
 * to be able to call the native functions in the ANE from their ActionScript code
*/
NSString* admobGetString(FREObject obj);
ANE_FUNCTION(admobHideBanner);
ANE_FUNCTION(admobShowBannerAbsolute);
ANE_FUNCTION(admobShowBanner);
ANE_FUNCTION(admobIsInterstitialReady);
ANE_FUNCTION(admobShowInterstitial);
ANE_FUNCTION(admobCacheInterstitial);
ANE_FUNCTION(getScreenSize);

ANE_FUNCTION(admobIsVideoReady);
ANE_FUNCTION(admobShowVideo);
ANE_FUNCTION(admobCacheVideo);
ANE_FUNCTION(admobSetAppMuted);
ANE_FUNCTION(admobSetAppVolume);
ANE_FUNCTION(admobInitAdmobSDK);



