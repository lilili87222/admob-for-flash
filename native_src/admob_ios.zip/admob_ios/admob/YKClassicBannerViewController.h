#import "YKBannerViewController.h"
#import <GoogleMobileAds/GADBannerView.h>
#import <GoogleMobileAds/GADRequest.h>
@interface YKClassicBannerViewController : YKBannerViewController <GADBannerViewDelegate>

@end
