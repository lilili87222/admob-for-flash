#import "YKClassicBannerViewController.h"

@interface YKClassicBannerViewController ()

@end

@implementation YKClassicBannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) sendRequest:(UIView*) bannerView withParam:(NSString*)param{
    [(GADBannerView*)bannerView loadRequest:[YKBannerViewController createRequest:param]];
}
-(UIView*) initBannerView:(NSString*) bannerKey withSize:(CGSize)cgsize {
    GADBannerView*  adBanner = [[GADBannerView alloc]
                                initWithAdSize:GADAdSizeFromCGSize(cgsize)]   ;
    adBanner.delegate = self;
    adBanner.rootViewController=self;
    adBanner.adUnitID=bannerKey;
    return adBanner;
}

/// Tells the delegate that an ad request successfully received an ad. The delegate may want to add
/// the banner view to the view hierarchy if it hasn't been added yet.
- (void)adViewDidReceiveAd:(GADBannerView *)bannerView{
    NSString *event_name = @"onBannerReceive";
    CGSize s=bannerView.frame.size;
    NSString *sizestr=[NSString stringWithFormat:@"%f_%f",s.width,s.height];
    [self sendEvent:event_name level:sizestr];
}

/// Tells the delegate that an ad request failed. The failure is normally due to network
/// connectivity or ad availablility (i.e., no fill).
- (void)adView:(GADBannerView *)bannerView didFailToReceiveAdWithError:(GADRequestError *)error{
    NSString *event_name = @"onBannerFailedReceive";
    [self sendEvent:event_name level:[error localizedDescription]];
}

#pragma mark Click-Time Lifecycle Notifications

/// Tells the delegate that a full screen view will be presented in response to the user clicking on
/// an ad. The delegate may want to pause animations and time sensitive interactions.
- (void)adViewWillPresentScreen:(GADBannerView *)bannerView{
    NSString *event_name = @"onBannerPresent";
    NSString *event_level = @"adViewWillPresentScreen";
    [self sendEvent:event_name level:event_level];
}

/// Tells the delegate that the full screen view will be dismissed.
- (void)adViewWillDismissScreen:(GADBannerView *)bannerView{
    NSString *event_name = @"onBannerDismiss";
    NSString *event_level = @"onWillDismissScreen";
    [self sendEvent:event_name level:event_level];
    
}

/// Tells the delegate that the full screen view has been dismissed. The delegate should restart
/// anything paused while handling adViewWillPresentScreen:.
- (void)adViewDidDismissScreen:(GADBannerView *)bannerView{
    NSString *event_name = @"onBannerDismiss";
    NSString *event_level = @"onDidDismissScreen";
    [self sendEvent:event_name level:event_level];
}

/// Tells the delegate that the user click will open another app, backgrounding the current
/// application. The standard UIApplicationDelegate methods, like applicationDidEnterBackground:,
/// are called immediately before this method is called.
- (void)adViewWillLeaveApplication:(GADBannerView *)bannerView{
    NSString *event_name = @"onBannerLeaveApplication";
    NSString *event_level = @"adViewWillLeaveApplication";
    [self sendEvent:event_name level:event_level];

}


@end
