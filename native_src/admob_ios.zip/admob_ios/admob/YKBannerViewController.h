#import <UIKit/UIKit.h>
#import "FlashRuntimeExtensions.h"
#import <GoogleMobileAds/GADRequest.h>
#import <GoogleMobileAds/GADBannerView.h>
#import <GoogleMobileAds/GADRequest.h>
#import <GoogleMobileAds/GADExtras.h>
#define AB_BANNER_POSITIONS_Absolute    0
#define AB_BANNER_POSITIONS_TOP_LEFT 1
#define AB_BANNER_POSITIONS_TOP_CENTER 2
#define AB_BANNER_POSITIONS_TOP_RIGHT 3
#define AB_BANNER_POSITIONS_MIDDLE_LEFT 4
#define AB_BANNER_POSITIONS_MIDDLE_CENTER 5
#define AB_BANNER_POSITIONS_MIDDLE_RIGHT 6
#define AB_BANNER_POSITIONS_BOTTOM_LEFT 7
#define AB_BANNER_POSITIONS_BOTTOM_CENTER 8
#define AB_BANNER_POSITIONS_BOTTOM_RIGHT 9
@interface YKBannerViewController : UIViewController
@property (nonatomic,assign) FREContext context;
@property (nonatomic,retain) NSMutableDictionary* bannerList;
@property (nonatomic,retain) NSMutableDictionary* bannerSizeList;

-(void) showBannerABS:(NSString*)bannerName atX:(int)_x atY:(int)_y withParam:(NSString*)param;
-(void) showRelationBanner:(NSString*)bannerName atPosition:(int)_p withOffY:(int)_offValue withParam:(NSString*)param;
-(void) removeBanner:(NSString*) bannerName;

-(UIView*) bannerViewForName:(NSString*)bannerName;
-(NSString*) createBanner:(NSString*) bannerID withName:(NSString*)bannerName withSize:(CGSize)bannerSize  withParam:(NSString*)param;
-(void) sendRequest:(UIView*) bannerView withParam:(NSString*)param;

- (void) addAdView:(UIView*)bannerView toParent:(UIView*) pview atPosition:(int) position  offX:(int)_x offY:(int)_y withAdSize:(CGSize) bannerSize;
-(void) deleteBanner:(NSString*) bannerName;
-(UIView*) initBannerView:(NSString*) bannerKey withSize:(CGSize)cgsize ;
-(void) sendEvent:(NSString *)type
            level:(NSString *)level;


+ (NSString *) admobDeviceID;
+(GADRequest*) createRequest:(NSString*) paramString;
@end
