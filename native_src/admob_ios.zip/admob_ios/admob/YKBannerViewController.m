#import "YKBannerViewController.h"
#import <AdSupport/AdSupport.h>
#include <CommonCrypto/CommonDigest.h>
#define iSIOS7 [[[UIDevice currentDevice]systemVersion] floatValue] < 8.0
@interface YKBannerViewController (){
    int lastPosition;
}

@end

@implementation YKBannerViewController
@synthesize context;
@synthesize bannerList;
@synthesize bannerSizeList;
- (id)init
{
    self = [super init];
    if (self) {
        bannerList=[[NSMutableDictionary alloc]init];
        bannerSizeList=[[NSMutableDictionary alloc]init];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) sendEvent:(NSString *)type
            level:(NSString *)level{
    if(context!=nil&&context!=nil){
        FREDispatchStatusEventAsync(context, (uint8_t*)[type UTF8String], (uint8_t*)[level UTF8String]);
    }
}
-(UIView*) bannerViewForName:(NSString*)bannerName{
    return [bannerList objectForKey:bannerName];
}
-(void) deleteBanner:(NSString*) bannerName{
    [self.bannerSizeList removeObjectForKey:bannerName];
    [self removeBanner:bannerName];
    [self.bannerList removeObjectForKey:bannerName];
    UIView* banner=[self.bannerList objectForKey:bannerName];
    [banner dealloc];
}
-(UIView*) initBannerView:(NSString*) bannerKey withSize:(CGSize)cgsize {
    return nil;
}
-(void) sendRequest:(UIView*) bannerView withParam:(NSString*)param{
}
-(NSString*) createBanner:(NSString*) bannerKey withName:(NSString*)bannerName withSize:(CGSize)bannerSize  withParam:(NSString *)param{
    CGSize cgsize=bannerSize;//CGSizeMake(w, h);
    if(cgsize.width==-1&&cgsize.height==-2){
        UIInterfaceOrientation org=[[UIApplication sharedApplication] statusBarOrientation];
        if(UIInterfaceOrientationIsLandscape(org)){
            cgsize=CGSizeFromGADAdSize(kGADAdSizeSmartBannerLandscape);
        }else{
            cgsize=CGSizeFromGADAdSize(kGADAdSizeSmartBannerPortrait);
        }
    }else if (cgsize.width==0&&cgsize.height==0){
        if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPhone){
            cgsize.width=320;
            cgsize.height=50;
            if(UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])){
                cgsize.width=468;
                cgsize.height=60;
            }
        }else{
            cgsize.width=728;
            cgsize.height=90;
        }
    }
    NSValue* sizeValue=[self.bannerSizeList objectForKey:bannerName];
    if(sizeValue!=nil){
        CGSize oldBannerSize= [sizeValue CGSizeValue];
        if(oldBannerSize.width!=cgsize.width&&oldBannerSize.height!=cgsize.height){
            return bannerName;
        }else{
            [self deleteBanner:bannerName];
        }
    }
    UIView* adBanner=[self initBannerView:bannerKey withSize:cgsize];
    [self.bannerList setValue:adBanner forKey:bannerName];
    [self.bannerSizeList setValue:[NSValue valueWithCGSize:cgsize] forKey:bannerName];
    [self sendRequest:adBanner withParam:param];
    return bannerName;
}


-(void) showBannerABS:(NSString*)bannerName atX:(int)_x atY:(int)_y withParam:(NSString *)param{
    UIView* bannerView=[bannerList objectForKey:bannerName];
    if(bannerView==nil)return;
    UIWindow* parentWin=[[UIApplication sharedApplication] keyWindow];
    if(parentWin==nil){
        parentWin=[[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    NSValue* sizeValue=[bannerSizeList objectForKey:bannerName];
    CGSize bannerSize=[sizeValue CGSizeValue];
    [self addAdView:bannerView toParent:parentWin atPosition:0 offX:_x offY:_y withAdSize:bannerSize];
   // [self sendRequest:bannerView withParam:param];
}
-(void) showRelationBanner:(NSString*)bannerName atPosition:(int)_p withOffY:(int)_offValue withParam:(NSString *)param{
    UIView* bannerView=[bannerList objectForKey:bannerName];
    if(bannerView==nil)return;
    UIWindow* parentWin=[[UIApplication sharedApplication] keyWindow];
    if(parentWin==nil){
        parentWin=[[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    NSValue* sizeValue=[bannerSizeList objectForKey:bannerName];
    CGSize bannerSize=[sizeValue CGSizeValue];
    [self addAdView:bannerView toParent:parentWin atPosition:_p offX:0 offY:_offValue withAdSize:bannerSize];
   // [self sendRequest:bannerView withParam:param];
}

-(void) removeBanner:(NSString*) bannerName{
    UIView* bannerView=[bannerList objectForKey:bannerName];
    if(bannerView!=nil){
        if(bannerView.superview!=nil){
            [bannerView removeFromSuperview];
        }
    }
}
- (void) addAdView:(UIView*)bannerView toParent:(UIView*) pview atPosition:(int) position  offX:(int)_x offY:(int)_y withAdSize:(CGSize) bannerSize{
    [bannerView setTranslatesAutoresizingMaskIntoConstraints:NO];
    if(bannerView.superview!=nil&&lastPosition!=position){
        [bannerView removeFromSuperview ];
    }
    if(pview.superview==nil)
    [pview addSubview:bannerView];
    lastPosition=position;
    
    CGSize bannerRect=bannerSize;//[self bannerSize:lastBannerType];
    
    NSLayoutConstraint* vheight =[NSLayoutConstraint constraintWithItem:bannerView
                                                              attribute:NSLayoutAttributeHeight
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:nil
                                                              attribute:NSLayoutAttributeNotAnAttribute
                                                             multiplier:0
                                                               constant:bannerRect.height];
    NSLayoutConstraint* vwidth =[NSLayoutConstraint constraintWithItem:bannerView
                                                             attribute:NSLayoutAttributeWidth
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:nil
                                                             attribute:NSLayoutAttributeNotAnAttribute
                                                            multiplier:0
                                                              constant:bannerRect.width];
    NSLayoutConstraint* leftDis= [NSLayoutConstraint constraintWithItem:bannerView attribute:NSLayoutAttributeLeft
                                                              relatedBy:NSLayoutRelationEqual toItem:pview attribute:NSLayoutAttributeLeft multiplier:1.0 constant:_x];
    NSLayoutConstraint* rightDis= [NSLayoutConstraint constraintWithItem:bannerView attribute:NSLayoutAttributeRight
                                                               relatedBy:NSLayoutRelationEqual toItem:pview attribute:NSLayoutAttributeRight multiplier:1.0 constant:0];
    
    NSLayoutConstraint* topDis= [NSLayoutConstraint constraintWithItem:bannerView attribute:NSLayoutAttributeTop
                                                             relatedBy:NSLayoutRelationEqual toItem:pview attribute:NSLayoutAttributeTop multiplier:1.0 constant:_y];
    NSLayoutConstraint* bottomDis= [NSLayoutConstraint constraintWithItem:bannerView attribute:NSLayoutAttributeBottom
                                                                relatedBy:NSLayoutRelationEqual toItem:pview attribute:NSLayoutAttributeBottom multiplier:1.0 constant:-_y];
    
    NSLayoutConstraint* xCenter= [NSLayoutConstraint constraintWithItem:bannerView attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual toItem:pview attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    NSLayoutConstraint* yCenter= [NSLayoutConstraint constraintWithItem:bannerView attribute:NSLayoutAttributeCenterY
                                                              relatedBy:NSLayoutRelationEqual toItem:pview attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0];
    [pview removeConstraints:bannerView.constraints];
    NSArray* usedConstraints=nil;
    if(position==AB_BANNER_POSITIONS_TOP_LEFT||position==AB_BANNER_POSITIONS_Absolute){
        usedConstraints=[NSArray arrayWithObjects:leftDis,topDis, nil];
    }
    else if(position==AB_BANNER_POSITIONS_TOP_CENTER){
        usedConstraints=[NSArray arrayWithObjects:xCenter,topDis, nil];
    }
    else if(position==AB_BANNER_POSITIONS_TOP_RIGHT){
        usedConstraints=[NSArray arrayWithObjects:rightDis,topDis, nil];
    }
    else if(position==AB_BANNER_POSITIONS_MIDDLE_LEFT){
        usedConstraints=[NSArray arrayWithObjects:leftDis,yCenter, nil];
    }
    else if(position==AB_BANNER_POSITIONS_MIDDLE_CENTER){
        usedConstraints=[NSArray arrayWithObjects:xCenter,yCenter, nil];
    }
    else if(position==AB_BANNER_POSITIONS_MIDDLE_RIGHT){
        usedConstraints=[NSArray arrayWithObjects:rightDis,yCenter, nil];
    }
    else if(position==AB_BANNER_POSITIONS_BOTTOM_LEFT){
        usedConstraints=[NSArray arrayWithObjects:leftDis,bottomDis, nil];
    }
    else if(position==AB_BANNER_POSITIONS_BOTTOM_CENTER){
        usedConstraints=[NSArray arrayWithObjects:xCenter,bottomDis, nil];
    }
    else if(position==AB_BANNER_POSITIONS_BOTTOM_RIGHT){
        usedConstraints=[NSArray arrayWithObjects:rightDis,bottomDis, nil];
    }
    [pview addConstraint:vwidth];
    [pview addConstraint:vheight];
    [pview addConstraints:usedConstraints];
}
+ (NSString *) admobDeviceID
{
    NSString* admobDeviceID;
    NSUUID* adid = [[ASIdentifierManager sharedManager] advertisingIdentifier];
    const char *cStr = [adid.UUIDString UTF8String];
    unsigned char digest[16];
    CC_MD5( cStr, strlen(cStr), digest );
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    admobDeviceID=output;
    return  output;
}
+(NSDictionary*) jsonToDic:(NSString*) _adProperties{
    NSDictionary* dic=nil;
    if(_adProperties!=nil){
        NSData* jsonData=[_adProperties dataUsingEncoding:NSUTF8StringEncoding];
        NSError* parseError=nil;
        id jsonObject=[NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&parseError];
        if(jsonObject!=nil&&[jsonObject isKindOfClass:[NSDictionary class]]){
            dic=(NSDictionary*)jsonObject;
        }
    }
    return dic;
}
+(GADRequest*) createRequest:(NSString*) paramString{
    NSDictionary* dic=[YKBannerViewController jsonToDic:paramString];
    GADRequest *request = [GADRequest request];
    GADExtras *ext=[[GADExtras alloc] init];
    if(dic!=nil){
        NSString *testDeviceID=[dic objectForKey:@"testDeviceID"];
        if(testDeviceID&&![testDeviceID isEqual:[NSNull null]]){
            if([@"true" isEqualToString:testDeviceID]){
                request.testDevices = [NSArray arrayWithObjects:[YKBannerViewController admobDeviceID],nil];
            }else{
               request.testDevices = [NSArray arrayWithObjects:testDeviceID,nil];
            }
        }
        id value=[dic objectForKey:@"nonPersonalizedAds"];
        if(value&&![value isEqual:[NSNull null]]&&[value boolValue]){
            ext.additionalParameters=@{@"npa":@"1"};
        }
       NSArray *keys= [dic objectForKey:@"keyWord"];
        if(keys&&![keys isEqual:[NSNull null]]){
            request.keywords=keys;
        }
    }
    [request registerAdNetworkExtras:ext];
    return request;
}
@end
